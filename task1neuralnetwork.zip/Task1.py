# multilayer perceptron is implimented in sklearn but we have asked to implement same using keras sequencial module
# KerasClassifier is same using keras library
# Importing the library

import numpy as np
np.set_printoptions(precision=3, suppress=True)
import keras

np.random.RandomState(seed=0)

# importing the data
from sklearn.datasets import load_iris
data = load_iris()

# train-test split

#from sklearn.model_selection import train_test_split
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    data['data'], data['target'], random_state=0)

# Importing keras and other required packages

from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.grid_search import GridSearchCV
#from sklearn.model_selection import GridSearchCV
from keras.models import model_from_json

# creating model object 
# 2 Hidden layer network with 1 dropout layer 

def make_model(optimizer='adam', hidden_size=32,dropout_rate=0.0):
    model = Sequential([
        Dense(hidden_size, input_dim = 4),
        Dropout(dropout_rate),
        Activation('relu'),
        Dense(hidden_size),
        Activation('relu'),
        Dense(3),
        Activation('softmax')
    ])
        
    model.compile(optimizer=optimizer, loss = 'categorical_crossentropy', metrics=['accuracy'])
    return model

# buidling KerasClassifier
clf = KerasClassifier(make_model)

# setting param grid ; we have included the hyperparam mentioned in word doc
# here dropout_rate is regularization param 
# Dropout is a technique where randomly selected neurons are ignored during training. They are “dropped-out” randomly. This means that their contribution to the activation of downstream neurons is temporally removed on the forward pass and any weight updates are not applied to the neuron on the backward pass.
# hidden_size : hidden units 

param_grid = {'dropout_rate' : [0.1, 0.2],
              'hidden_size':  [10, 32, 64]}

# grid search for best param over train data

grid = GridSearchCV(clf, param_grid = param_grid, cv = 2)
grid.fit(X_train, y_train)

print(grid.best_params_)

h_size=grid.best_params_['hidden_size'] # 64
dropoutrate=grid.best_params_['dropout_rate'] # 0.2

# creating model objects for best paramas found above
def make_model(optimizer='adam', hidden_size=h_size,dropout_rate=dropoutrate):
    model = Sequential([
        Dense(hidden_size, input_dim = 4),
        Dropout(dropout_rate),
        Activation('relu'),
        Dense(hidden_size),
        Activation('relu'),
        Dense(3),
        Activation('softmax')
    ])        
    model.compile(optimizer=optimizer, loss = 'categorical_crossentropy', metrics=['accuracy'])
    return model

num_classes = 3
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)

# using best param again fitted on train
model = make_model()
model.fit(X_train, y_train,
          epochs=10,
          batch_size=3,
          validation_split=.1)
print('\nSummary:\n\n')
model.summary()

'''
# saving the model if you do not want to train model again which usually saves time

# serialize model to JSON
model_json = model.to_json()
with open("Task1_model.json", "w") as json_file:
    json_file.write(model_json)
# serialize weights to HDF5
model.save_weights("Task1_model.h5")
print("Saved model to disk")


# reload the saved model

# load json and create model
json_file = open('Task1_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights("Task1_model.h5")
print("Loaded model from disk")

# prediction using the stored model

# evaluate loaded model on test data
loaded_model.compile(optimizer='adam', loss = 'categorical_crossentropy', metrics=['accuracy'])
loaded_model_score = loaded_model.evaluate(X_test, y_test, batch_size=3, verbose=0)
print("\nTest loss: {:.3f}".format(loaded_model_score[0])) # Test loss: 0.173
print("Test Accuracy: {:.3f}".format(loaded_model_score[1])) # Test Accuracy: 0.947
'''

# model evaluation  on test data
score = model.evaluate(X_test, y_test, batch_size=3, verbose=0)

print("\nTest loss: {:.3f}".format(score[0])) # Test loss: 0.173
print("Test Accuracy: {:.3f}".format(score[1])) # Test Accuracy: 0.947
