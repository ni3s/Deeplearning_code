## Load the pre-trained model for evaluation and predictoin

import numpy as np
np.set_printoptions(precision=3, suppress=True)
import keras

np.random.RandomState(seed=0)

# importing the data
from sklearn.datasets import load_iris
data = load_iris()

# train-test split
#from sklearn.model_selection import train_test_split
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    data['data'], data['target'], random_state=0)

# Importing keras and other required packages

from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.grid_search import GridSearchCV
#from sklearn.model_selection import GridSearchCV
from keras.models import model_from_json

num_classes = 3
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)


# load the saved model

# load json and create model
json_file = open('Task1_model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights("Task1_model.h5")
print("Loaded model from disk")

# prediction using the stored model

# evaluate loaded model on test data
loaded_model.compile(optimizer='adam', loss = 'categorical_crossentropy', metrics=['accuracy'])
loaded_model_score = loaded_model.evaluate(X_test, y_test, batch_size=3, verbose=0)
print("\nTest loss: {:.3f}".format(loaded_model_score[0])) # Test loss: 0.173
print("Test Accuracy: {:.3f}".format(loaded_model_score[1])) # Test Accuracy: 0.947
